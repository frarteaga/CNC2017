#include <iostream>
#include <cstdio>
#include <vector>
#include <map>
#include <algorithm>
#include <ctime>

using namespace std;

struct query {
    int parent;
    int color;
    int index;

    query(int p, int c, int i):
        parent(p), color(c), index(i) {}

    bool operator < (const query& other) const {
        if (parent != other.parent)
            return parent < other.parent;
        return color < other.color;
    }
};

void solve() {
    int N, M, K;
    scanf("%d%d%d", &N, &M, &K);

    vector<int> A(N + 1);
    for (int i = 1; i <= N; ++i)
        scanf("%d", &A[i]);

    vector<int> P(N + 1);
    P[2] = 1;
    for (int i = 3; i <= N; ++i)
        scanf("%d", &P[i]);

    vector<int> X(M), Y(M);
    for (int mi = 0; mi < M; ++mi) {
        scanf("%d%d", &X[mi], &Y[mi]);
    }

    vector<query> colors;
    vector<int> p_index(N + 1);
    vector<int> v_index(N + 1);
    vector<int> value(N + N + M + M);
    vector<int> p_new_index(M);
    vector<int> v_new_index(M);

    colors.reserve(N + N + M + M);
    for (int i = 2; i <= N; ++i) {
        colors.push_back(query(P[i], A[i], i));
    }
    for (int i = 1; i <= N; ++i) {
        colors.push_back(query(i, A[i], i + N));
    }

    for (int mi = 0; mi < M; ++mi) {
        colors.push_back(query(P[X[mi]], Y[mi], 2 * N + mi + 1));
        colors.push_back(query(X[mi], Y[mi], 2 * N + M + mi + 1));
    }

    sort(colors.begin(), colors.end());

    int ind = 0;
    for (int i = 0; i < colors.size();) {
        int j;
        for (j = i; j < colors.size() && colors[i].parent == colors[j].parent && colors[i].color == colors[j].color; ++j) {
            if (colors[j].index <= N) {
                p_index[colors[j].index] = ind;
                ++value[ind];
                continue;
            }
            if (colors[j].index <= 2 * N) {
                v_index[colors[j].index - N] = ind;
                continue;
            }
            if (colors[j].index <= 2 * N + M) {
                p_new_index[colors[j].index - 1 - N - N] = ind;
                continue;
            }
            v_new_index[colors[j].index - 1 - N - N - M] = ind;
        }
        i = j;
        ++ind;
    }

    int ans = 0;
    for (int i = 1; i <= N; ++i)
        ans += value[v_index[i]];

    for (int mi = 0; mi < M; ++mi) {
        if (A[P[X[mi]]] == A[X[mi]]) --ans;
        ans -= value[v_index[X[mi]]];
        --value[p_index[X[mi]]];

        A[X[mi]] = Y[mi];

        if (A[P[X[mi]]] == A[X[mi]]) ++ans;
        p_index[X[mi]] = p_new_index[mi];
        v_index[X[mi]] = v_new_index[mi];

        ans += value[v_index[X[mi]]];
        ++value[p_index[X[mi]]];

        printf("%d\n", ans);
    }
}

int main() {
	freopen("dosc.in", "r", stdin);
	freopen("dosc.out", "w", stdout);

    solve();

   // cerr << clock() << endl;
    return 0;
}
