#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;

const long long BASE = 1LL << 60;

struct rational {
    long long n, d;
    rational(long long n = 0, long long d = 1) : n(n), d(d) {}
    
    static rational norm(const rational & r) {
        long long g = gcd(r.n, r.d);
        return rational(r.n / g, r.d / g);
    }
    
    static long long gcd(long long a, long long b) { return b ? gcd(b, a % b) : a; }
    
    rational operator + (const rational& other) const {
	long long g = gcd(other.d, this->d);
        return norm(rational(this->n * (other.d / g) + other.n * (this->d / g), this->d / g * other.d));
    }
    
    rational operator / (const rational& other) const {
        return norm(rational(this->n * other.d, this->d * other.n));
    }
};

typedef pair<int, int> pii;
typedef pair<long long, long long> LongInt;

pii get_max_lower(const vector<pii>& fenw, int id) {
    ++id;
    pii res = fenw[id];
    while (id > 0) {
        res = max(res, fenw[id]);
        id &= id - 1;
    }
    return res;
}

void set(vector<pii> & fenw, int id, pii value) {
    ++id;
    while (id < fenw.size()) {
        fenw[id] = max(fenw[id], value);
        id = id * 2 - (id & (id - 1));
    }
}

vector<int> find(vector<int> a, int M, int K, rational X) {
    const int N = a.size();
    
    vector<long long> B(N);
    for (int i = 0; i < N; ++i)
        B[i] = a[i] * X.d - X.n;
    
    typedef pair<LongInt, int> TSum;    
    vector<TSum> sum(N + 1);
    for (int i = 0; i < N; ++i) {
        LongInt sm;
        sm.first = sum[i].first.first;
        sm.second = sum[i].first.second + B[i];
        while (sm.second >= BASE) {
            ++sm.first;
            sm.second -= BASE;
        }
        while (sm.second < 0) {
            --sm.first;
            sm.second += BASE;
        }
        sum[i + 1] = make_pair(sm, i + 1);
    }

    sort(sum.begin(), sum.end());
    
    vector<int> best(N + 1, -1);
    vector<int> prev(N + 1, -1);
    vector<pii> fenw(N + 2, pii(-1, -1));

    best[0] = 0;
    for (int it = 0; it <= N; ++it) {
        int i = sum[it].second;
        if (i - M >= 0) {
            pii got = get_max_lower(fenw, i - M);
            if (got.first >= 0) {
                best[i] = got.first + 1;
                prev[i] = got.second; 
            }
        }
        if (best[i] >= 0) {
            set(fenw, i, pii(best[i], i));
        }
    }
    
    vector<int> answer;
    int r = K;
    int p = N;
    while (best[p] >= r && r > 0) {
        if (r > 1)
            answer.push_back(p - prev[p]);
        else
            answer.push_back(p);
        --r;
        p = prev[p];
    }
    reverse(answer.begin(), answer.end());
    return answer;
}

void solve() {
    int N, M, K;
    cin >> N >> M >> K;
    
    vector<int> a(N);
    for (int i = 0; i < N; ++i)
        cin >> a[i];
    
    rational L(0);
    rational R(1 << 30);
    
    vector<int> ans;
    
    while (max(L.d, R.d) <= N * (N - 1)) {
        rational middle = (L + R) / 2;
        
        vector<int> c = find(a, M, K, middle);
        if (c.size() == K) {
            ans = c;
            L = middle;
        } else {
            R = middle;
        }
    }
    
    for (int i = 0; i < ans.size(); ++i) {
        if (i > 0) cout << ' ';
        cout << ans[i];
    }
    cout << endl;
}

int main() {
    freopen("dosb.in", "r", stdin);
    freopen("dosb.out", "w", stdout);
    
    solve();
    
    return 0;
}
