//Raidel Marichal
#include<bits/stdc++.h>
using namespace std;

int n, m, k;
int color[300000];
int P[300000];
vector <vector<int> > adj;

void UNION(int x, int y){
    P[y] = x;
}

int pares(){
    int ans = 0;
    for (int i=1; i<n; i++){
        if (P[i] != i && color[i] == color[P[i]]) ans++;
    }
    return ans;
}

int main(){
    freopen("dosc.in", "r", stdin);
    freopen("dosc.out", "w", stdout);

    ios_base::sync_with_stdio(0);
    cin.tie(0);

    cin >> n >> m >> k;
    adj.resize(n);

    for (int i=0; i<n; i++){
        cin >> color[i];
        P[i] =  i;
    }


    int p;
    UNION(0, 1);
    adj[0].push_back(1);
    adj[1].push_back(0);

    for (int i=2; i<n; i++){
        cin >> p;
        UNION(--p, i);
        adj[p].push_back(i);
        adj[i].push_back(p);
    }

    int u, newcolor, oldcolor;
    int total_pares = pares();
    for (int i=0; i<m; i++){
        cin >> u >> newcolor;
        oldcolor = color[--u];
        color[u] =  newcolor;
        for (int j = 0; j<adj[u].size(); j++){
            int c = color[ adj[u][j] ];
            if (newcolor == c && oldcolor != c) total_pares++;
            if (newcolor != c && oldcolor == c) total_pares--;
        }
        cout << total_pares << endl;
    }
}

/*
3 3 3
1 2 3
2
2 1
3 1
2 2

7 3 4
2 1 2 4 4 1 2
1 1 2 1 2
2 2
2 1
6 2
*/
