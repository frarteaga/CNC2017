#include <bits/stdc++.h>

using namespace std;

#define MAXN 105

int N, M, K;
vector<int> V[MAXN], G[MAXN];

int k, Td[MAXN], low[MAXN];
bool mark[MAXN];
int cant[MAXN], Comp[MAXN], cfc;
stack <int> P;
void Tarjan_SCC( int nod ){
	Td[nod] = low[nod] = ++ k;
	P.push( nod );
	for( auto newn : V[nod] ){
		if( Td[newn] ){
			if( !mark[newn] )
				low[nod] = min( low[nod], Td[newn] );
			continue;
		}
		Tarjan_SCC( newn );
		low[nod] = min( low[nod], low[newn] );
	}
	if( low[nod] == Td[nod] ){
		cfc ++;
		while( !mark[nod] ){
			mark[(int)P.top()] = true;
			cant[cfc] ++;
			Comp[P.top()] = cfc;
			P.pop();
		}
	}
}
bool degE[MAXN], degS[MAXN];
int val[MAXN], num;
long long T[MAXN][MAXN], Dp[MAXN][MAXN];
long long mod = 1e9+7;

int main()
{
    freopen("dosa.in", "r", stdin);
    freopen("dosa.out", "w", stdout);


    cin >> N >> M >> K;

    int a, b;
    for( int i = 1; i <= M; i ++ ){
        cin >> a >> b;
        V[a].push_back( b );
    }

    for( int i = 1; i <= N; i ++ )
        if( !Td[i] )
            Tarjan_SCC( i );

     for( int i = 1; i <= N; i ++ )
        for( auto j : V[i] ) if( Comp[i] != Comp[j] ){
            degS[Comp[i]] = true;
            degE[Comp[j]] = true;
            G[Comp[i]].push_back( Comp[j] );
            G[Comp[j]].push_back( Comp[i] );
        }

     for( int i = 1; i <= cfc; i ++ )
        if( degE[i] == false || degS[i] == false ){
           val[++num] = cant[i];
        }

     for( int i = 0; i <= 100; i ++ )
        for( int j = 0; j <= i; j ++ ){
          if( j == 0 || j == i )
            T[i][j] = 1ll;
          else
            T[i][j] = (T[i-1][j] + T[i-1][j-1])%mod;
        }

    Dp[0][0] = 1ll;
    for( int l = 1; l <= num; l ++ )
        for( int i = l; i >= 1; i -- )
            for( int j = val[l]; j <= N; j ++ )
                Dp[i][j] = (Dp[i][j] + Dp[i-1][j-val[l]])%mod;

    long long solucion = T[N][K], S;
    for( int i = 1; i <= num; i ++ ){
        S = 0;
        for( int j = 1; j <= N-K; j ++ )
           if( N - j >= K && Dp[i][j] != 0 )
             S = (S + (Dp[i][j]*T[N-j][K])%mod)%mod;

        if( i&1 )
         solucion = (solucion - S + mod)%mod;
        else
         solucion = (solucion + S)%mod;
    }

    cout << solucion << '\n';

    return 0;
}
