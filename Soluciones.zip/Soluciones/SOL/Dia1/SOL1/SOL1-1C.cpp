#include <bits/stdc++.h>

using namespace std;

int T, N;
long long sum;
struct r{
 long long p, s, d;
}G[100005];
bool comp( const r s1, const r s2 ){
  //if( s1.d != s2.d ) return s1.d < s2.d;
  //return s1.s < s2.s;
//  return s1.d*(sum-s1.s) < s2.d*(sum-s2.s);
  return s1.d*s2.s < s2.d*s1.s;
}

int main()
{

    freopen("unoc.in", "r", stdin);
    freopen("unoc.out", "w", stdout);

 //   cin >> T;

 //   while( T -- ){
        cin >> N;
        for( int i = 1; i <= N; i ++ ){
            cin  >> G[i].p >> G[i].s >> G[i].d;
            sum += G[i].s;
        }

        sort( G+1, G+1+N, comp );

        long long sol = 0, tim = 0;
        for( int i = 1; i <= N; i ++ ){
            tim += G[i].d;
            sol += (G[i].p - G[i].s*tim);
        }

        cout << sol << '\n';
  //  }

    return 0;
}
