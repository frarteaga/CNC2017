#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
int T;
ll C[105][105];
int k;

int num[105];
ll solve( ll n ){
   int bits = k;
   ll sol = 0;
   for( int i = 30; i >= 0 && bits >= 0; i -- )
        if( n & (1ll<<i) ){
            sol += C[i][bits];
            bits --;
        }
   return sol + (bits == 0);
}


int main()
{
    freopen("unoa.in", "r", stdin);
    freopen("unoa.out", "w", stdout);

    for( int i = 0; i <= 32; i ++ )
        for( int j = 0; j <= i; j ++ )
                C[i][j] = ( j == 0 || j == i )? 1ll :C[i-1][j-1]+C[i-1][j];

    scanf("%d", &T);

	ll a, b;
    while( T -- ){
        scanf("%lld%lld%d", &a, &b, &k);
        assert( a <= b && k <= 31 );
        printf("%lld\n", solve( b ) - solve( a-1 ));
    }

    return 0;
}
