#include <bits/stdc++.h>

using namespace std;

int T;
long long a, b;
int k;

int cant( long long n ){
    int s = 0;
    for( int i = 0; i < 32; i ++ )
        if( n & (1ll << i) )
            s ++;
    return s;
}

int main()
{

    freopen("unoa.in", "r", stdin);
    freopen("unob.out", "w", stdout);

    scanf("%d", &T);

    while( T -- ){
        scanf("%lld%lld%d", &a, &b, &k);
        int sol = 0;
        for( long long i = a; i <= b; i ++ )
            if( cant( i ) == k )
                sol ++;

        printf("%d\n", sol);
    }

    return 0;
}
