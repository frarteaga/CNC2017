#include <bits/stdc++.h>

using namespace std;
#define MAXN 100005

int N, M, K;
vector<int> V[MAXN];
int num, E[MAXN], C[MAXN];
bool mark[MAXN];

void Dfs( int nod ){
    C[num] ++;
    mark[nod] = true;
    E[num] += (int)V[nod].size();
    for( auto i : V[nod] )
        if( !mark[i] )
            Dfs( i );
}

int main()
{
    freopen("unob.in", "r", stdin);
    freopen("unob.out", "w", stdout);

    scanf("%d%d%d", &N, &M, &K);

    int a, b;
    for( int i = 1; i <= M; i ++ ){
        scanf("%d%d", &a, &b);
        V[a].push_back( b );
        V[b].push_back( a );
    }

    for( int i = 1; i <= N; i ++ )
        if( !mark[i] ){
            num ++;
            Dfs( i );
            E[num] /= 2;
        }

    printf("%d ", max( 1, num-K )); /// min cant. de componentes

    for( int i = 1; i <= num && K ; i ++ )
        K -= min( K, ( (C[i]*(C[i]-1))/2 ) - E[i] );

    sort( C+1, C+1+num );

    int cant = C[num];
    for( int i = num-1; i >= 1 && K; i -- ){
        K -= min( 1ll*K, 1ll*cant*C[i] );
        cant += C[i], num --;
    }

    printf("%d\n", num); /// max cant. de componentes

    return 0;
}
